drop table member;
drop table board1;
drop table board2;
drop table board3;
drop table board4;
drop table bulletin;
commit;
