create sequence member_seq start with 1 increment by 1;
create sequence board1_seq start with 1 increment by 1;
create sequence board2_seq start with 1 increment by 1;
create sequence board3_seq start with 1 increment by 1;
create sequence board4_seq start with 1 increment by 1;
commit;