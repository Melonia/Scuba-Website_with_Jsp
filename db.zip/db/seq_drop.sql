drop sequence member_seq;
drop sequence board1_seq;
drop sequence board2_seq;
drop sequence board3_seq;
drop sequence board4_seq;
commit;
