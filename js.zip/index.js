$(function(){
	$(".bullet>li:nth-child(1)").click(function(){
		$("#picture div div:nth-child(1) img").css("height","100%");
		$("#picture div div:nth-child(2) img").css("height","0");
		$("#picture div div:nth-child(3) img").css("height","0");
	});
	$(".bullet>li:nth-child(2)").click(function(){
		$("#picture div div:nth-child(1) img").css("height","0");
		$("#picture div div:nth-child(2) img").css("height","100%");
		$("#picture div div:nth-child(3) img").css("height","0");
	});
	$(".bullet>li:nth-child(3)").click(function(){
		$("#picture div div:nth-child(1) img").css("height","0");
		$("#picture div div:nth-child(2) img").css("height","0");
		$("#picture div div:nth-child(3) img").css("height","100%");
	});
});