$(function(){
	$(".bullet>li:nth-child(1)").click(function(){
		$("#picture div div:nth-child(1) img").css("height","100%");
		$("#picture div div:nth-child(2) img").css("height","0");
		$("#picture div div:nth-child(3) img").css("height","0");
	});
	$(".bullet>li:nth-child(2)").click(function(){
		$("#picture div div:nth-child(1) img").css("height","0");
		$("#picture div div:nth-child(2) img").css("height","100%");
		$("#picture div div:nth-child(3) img").css("height","0");
	});
	$(".bullet>li:nth-child(3)").click(function(){
		$("#picture div div:nth-child(1) img").css("height","0");
		$("#picture div div:nth-child(2) img").css("height","0");
		$("#picture div div:nth-child(3) img").css("height","100%");
	});
});

function login(num){
	if(num == 1){
	document.getElementById("login_form").style.visibility='visible';
	document.getElementById("join_form").style.visibility='hidden';
	}
	else{
		document.getElementById("login_form").style.visibility='hidden';
		document.getElementById("join_form").style.visibility='visible';
	}
}
function intro(num){
	if(num == 1){
		document.getElementById("greeting").style.visibility='visible';
		document.getElementById("teacher").style.visibility='hidden';
	}
	else{
		document.getElementById("greeting").style.visibility='hidden';
		document.getElementById("teacher").style.visibility='visible';
	}
}
function edu(num){
	if(num == 1){
		document.getElementById("edu_curriculum").style.visibility='visible';
		document.getElementById("edu_application").style.visibility='hidden';
	}
	else{
		document.getElementById("edu_curriculum").style.visibility='hidden';
		document.getElementById("edu_application").style.visibility='visible';
	}
}