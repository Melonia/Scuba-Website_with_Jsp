package com.scuba.controller;

import com.scuba.controller.action.Action;
import com.scuba.controller.action.Board1ListAction;
import com.scuba.controller.action.Board1WriteAction;
import com.scuba.controller.action.Board2ListAction;
import com.scuba.controller.action.Board2WriteAction;
import com.scuba.controller.action.Board2WriteFormAction;
import com.scuba.controller.action.LogoutAction;

public class ActionFactory {
	private static ActionFactory instance = new ActionFactory();
	
	private ActionFactory() {
		super();
	}
	
	public static ActionFactory getInstance() {
		return instance;
	}
	
	public Action getAction(String command) {
		Action action = null;
		System.out.println("ActionFactory:"+command);
		if(command.equals("board1_list")) {
			action = new Board1ListAction();
		}
		if(command.equals("board1_write")) {
			action = new Board1WriteAction();
		}
		if(command.equals("board2_list")) {
			action = new Board2ListAction();
		}
		if(command.equals("board2_write_form")) {
			action = new Board2WriteFormAction();
		}
		if(command.equals("board2_write")) {
			action = new Board2WriteAction();
		}
		if(command.equals("logout")){
			action = new LogoutAction();
		}
		return action;
	}
}
